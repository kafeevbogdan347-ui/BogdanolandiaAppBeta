const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT.firebaseio.com",
    projectId: "YOUR_PROJECT",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

let currentUser = null;
let isBgdLanguage = false;
let activeChatMode = 'global';

function login() {
    const nick = document.getElementById('reg-nick').value.trim();
    const role = document.getElementById('reg-role').value;
    
    if (nick.length < 3) {
        alert("Ошибка: Никнейм не может быть короче 3 символов!");
        return;
    }

    let location = "г. Семеновск";
    if (nick === "Яр-Крум") {
        location = "г. Богдановск (Столица)";
    }

    currentUser = {
        nick: nick,
        role: role,
        location: location,
        id: "BGD-" + Math.floor(1000 + Math.random() * 9000)
    };
    
    if (currentUser.nick === "Яр-Крум") {
        document.getElementById('admin-nav-btn').classList.remove('hidden');
    }

    if (localStorage.getItem('bgd_banned_' + currentUser.nick) === "true") {
        document.getElementById('auth-screen').classList.add('hidden');
        document.getElementById('tribunal-screen').classList.remove('hidden');
        document.getElementById('banned-nick').innerText = currentUser.nick;
        return;
    }

    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('app-screen').classList.remove('hidden');
    
    document.getElementById('user-info').innerText = `[${currentUser.role}] ${currentUser.nick} • ${currentUser.location}`;
    
    drawPassportCard();
}

function drawPassportCard() {
    const canvas = document.getElementById('passport-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    ctx.fillStyle = "#161616";
    ctx.fillRect(0, 0, 350, 200);
    
    ctx.fillStyle = "#000000"; ctx.fillRect(240, 30, 80, 140);
    ctx.fillStyle = "#bdc3c7"; ctx.fillRect(250, 30, 10, 140); ctx.fillRect(275, 30, 10, 140); ctx.fillRect(300, 30, 10, 140);
    ctx.fillStyle = "#c0392b"; ctx.fillRect(240, 30, 80, 35);
    ctx.strokeStyle = "#f1c40f"; ctx.lineWidth = 3; ctx.strokeRect(240, 30, 80, 140);

    ctx.fillStyle = "#ffcc00"; ctx.font = "bold 14px 'Courier New'";
    ctx.fillText("ПАСПОРТ БОГДАНОЛАНДИИ", 15, 30);
    
    ctx.strokeStyle = "#333"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(15, 42); ctx.lineTo(220, 42); ctx.stroke();
    
    ctx.fillStyle = "#ffffff"; ctx.font = "12px 'Courier New'";
    ctx.fillText("ГРАЖДАН_ИН: " + currentUser.nick, 15, 70);
    ctx.fillText("СЛУЖБА: " + currentUser.role, 15, 95);
    ctx.fillText("ПРОПИСКА: " + currentUser.location, 15, 120);
    
    ctx.fillStyle = "#e74c3c"; ctx.font = "bold 13px 'Courier New'";
    ctx.fillText("ID: " + currentUser.id, 15, 160);
}

function switchTab(tabId) {
    if (document.getElementById('emergency-overlay').classList.contains('hidden') === false && currentUser.nick !== "Яр-Крум") {
        if (tabId !== 'tab-chat' && tabId !== 'tab-passport') {
            alert("Доступ заблокирован: Введено Чрезвычайное Положение! Разрешены только Свезь и Просмотр ID.");
            return;
        }
    }

    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    
    document.getElementById(tabId).classList.add('active');
    event.target.classList.add('active');
}

function switchChat(mode) {
    activeChatMode = mode;
    document.getElementById('chat-global-btn').classList.remove('active-toggle');
    document.getElementById('chat-log-btn').classList.remove('active-toggle');
    
    if (mode === 'global') {
        document.getElementById('chat-global-btn').classList.add('active-toggle');
    } else {
        document.getElementById('chat-log-btn').classList.add('active-toggle');
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const box = document.getElementById('global-chat-box');
    if (input.value.trim() === "") return;

    const msgDiv = document.createElement('div');
    if (currentUser.nick === "Яр-Крум") {
        msgDiv.className = "msg-president";
        msgDiv.innerText = `[Президент] ${currentUser.nick}: ${input.value}`;
    } else {
        msgDiv.className = "msg-user";
        msgDiv.innerText = `[${currentUser.role}] ${currentUser.nick}: ${input.value}`;
    }

    box.appendChild(msgDiv);
    box.scrollTop = box.scrollHeight;

    if (activeChatMode === 'global' && currentUser.nick === "Яр-Крум") {
        const logBox = document.getElementById('global-chat-box');
        const sysDiv = document.createElement('div');
        sysDiv.className = "msg-system";
        sysDiv.innerText = `Летопись: Зафиксировано устное распоряжение Президента.`;
        logBox.appendChild(sysDiv);
    }

    input.value = "";
}

function payTax() {
    const currentFe = parseInt(document.getElementById('global-iron').innerText);
    document.getElementById('global-iron').innerText = currentFe + 10;
    alert("Экономическая обязанность исполнена. Налог 10 Fe зачислен в государственную казну. Слава Богданоландии!");
}

function takeLeave() {
    alert("Статус изменен: Вы ушли в официальный отпуск. Начисление долгов по налогам временно приостановлено.");
}

function searchDict() {
    const word = document.getElementById('dict-search').value.toLowerCase().trim();
    const dictionary = {
        "привет": "хыр",
        "железо": "валбра",
        "строительство": "архитекта",
        "президент": "крум",
        "база": "цитадель",
        "закон": "устав"
    };

    const result = dictionary[word];
    const display = document.getElementById('dict-result');
    
    if (result) {
        display.innerText = `Официальный перевод: ${result.toUpperCase()}`;
    } else {
        display.innerText = "Слово не найдено в архивах Министерства Культуры.";
    }
}

function startTikTokMode() {
    const container = document.getElementById('camera-container');
    const video = document.getElementById('video-preview');
    container.classList.remove('hidden');
    
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => { video.srcObject = stream; })
        .catch(err => { alert("Внимание: Системе не удалось получить доступ к камере мобильного телефона. Проверьте разрешения."); });
}

function triggerAlarm(type) {
    const alarm = document.getElementById('alarm-overlay');
    if (type === 'test') {
        alarm.innerText = "ТЕСТОВАЯ ПРОВЕРКА СВЯЗИ ТЕРМИНАЛА (БЕЗ ЗВУКА)";
        alarm.classList.remove('hidden');
        setTimeout(() => alarm.classList.add('hidden'), 3000);
    } else {
        alarm.innerText = "ВНИМАНИЕ! ОБЩАЯ ТРЕВОГА! ВСЕМ НА ТОЧКУ СБОРА!";
        alarm.classList.toggle('hidden');
    }
}

function toggleEmergency() {
    document.getElementById('emergency-overlay').classList.toggle('hidden');
}

function publishDecree() {
    const input = document.getElementById('decree-input');
    if (input.value.trim() === "") return;
    
    document.getElementById('decree-text').innerText = input.value;
    document.getElementById('decree-popup').classList.remove('hidden');
    input.value = "";
}

function banUser() {
    const target = document.getElementById('ban-nick').value.trim();
    if (target === "") return;
    
    localStorage.setItem('bgd_banned_' + target, "true");
    alert(`Гражданин ${target} официально осужден Судебным Исполнителем и изгнан.`);
    document.getElementById('ban-nick').value = "";
}

function amnestyUser() {
    const target = document.getElementById('ban-nick').value.trim();
    if (target === "") return;
    
    localStorage.removeItem('bgd_banned_' + target);
    alert(`Гражданин ${target} полностью амнистирован Президентом и восстановлен в правах.`);
    document.getElementById('ban-nick').value = "";
}

function toggleLanguage() {
    isBgdLanguage = !isBgdLanguage;
    document.getElementById('lang-title').innerText = isBgdLanguage ? "YAR-KRUM TERMINAL" : "СИСТЕМА БОГДАНОЛАНДИИ";
    document.getElementById('btn-passport').innerText = isBgdLanguage ? "ID Card" : "Паспорт";
    document.getElementById('btn-economy').innerText = isBgdLanguage ? "Valbra" : "Казна Fe";
}
